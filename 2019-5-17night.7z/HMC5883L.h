#ifndef _HMC5883L_H__
#define _HMC5883L_H__
#include <Wire.h>
#include"Arduino.h"

class HMC5883L
{
  private:
    int address;
    int x;
    int y;
    int z;
    int offsetX,offsetY,offsetZ;  
    float angle;
    float a[10];
  public:
    void INIT();
    void calibrateMag();
    void getRawData(int* x ,int* y,int* z) ;
    float calculateHeading(int* x ,int* y,int* z) ;
};
#endif

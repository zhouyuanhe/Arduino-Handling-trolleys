#ifndef _CAR_H__
#define _CAR_H__
class car{
  public:
  int lcd[5];//保存五个传感器的读取情况
  car();
  void motor(int left,int right);//两轮子速度的控制
  int lcd_read();//更新五个传感器的数据
  void runfoward(int i);//直走
  void runback(int j);//回头
  void turnL(int m);//左转
  void turnR(int n);//右转
  void stop();//停
  void followline();//巡线
private:
  void motor(char pin,char pwmpin,char state,int val);
  int leftA_PIN;//记录引脚位置
  int leftB_PIN;
  int righA_PIN;
  int righB_PIN;
  
};
class
#endif

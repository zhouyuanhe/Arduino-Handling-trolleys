#include"car.h"
#include<arduino.h>
car::car()//一些变量的初始化
{
  int leftA_PIN=4;
  int leftB_PIN=5;
  int righA_PIN=6;
  int righB_PIN=7; 
  pinMode(leftA_PIN,OUTPUT);  
  pinMode(leftB_PIN,OUTPUT);
  pinMode(righA_PIN,OUTPUT);
  pinMode(righB_PIN,OUTPUT);
}
int car::lcd_read()//更新lcd的数值
{
  int sum=0;
  lcd[0]= analogRead(A0)>200? 1:0;
  lcd[1]= analogRead(A1)>500? 1:0;
  lcd[2]= analogRead(A2)>700? 1:0;
  lcd[3]= analogRead(A3)>700? 1:0;
  lcd[4]= analogRead(A6)>200? 1:0;
  for(int i =0;i<5;i++){
    sum+=lcd[i];
  }
  return sum;
}
void car::motor(char pin,char pwmpin,char state,int val)
{

    pinMode(pin, OUTPUT);   
  if(state==1)
  {  
    analogWrite(pwmpin,val);
    digitalWrite(pin,1);
   }
  else if(state==2)
 {  
   analogWrite(pwmpin,val);
   digitalWrite(pin,0);
 }
 else if(state==0)
 {
    analogWrite(pwmpin,0);
    digitalWrite(pin,0);
 }
}
void car::runfoward(int i)   //前进
{
  motor(4,5,1,i);
  motor(7,6,1,i);
}
void car::runback(int j)    //后退
{
   motor(4,5,2,j);
   motor(7,6,2,j); 
}
void car::turnL(int m)     //左转
{
  motor(4,5,1,m);
  motor(7,6,0,m);
}
void car::turnR(int n)      //右转 
{
  motor(4,5,0,n);
  motor(7,6,1,n);
}
void car::stop()            //停止
{
  motor(4,5,0,0);
  motor(7,6,1,0); 
}
void car::followline()//巡线(即将完工、敬请期待)
{
} 

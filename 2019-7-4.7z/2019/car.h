#ifndef _CAR_H__
#define _CAR_H__
class car{
  public:
  int f;//定义一个变量记录是否进入黑线交界处
  int k;//记录当前路口数
  int lcd_s[5];
  int lcd[5];//保存五个传感器的读取情况
  car(int LA, int LB, int RA, int RB,int L1, int L2, int R1, int R2);
  int lcd_read();//更新五个传感器的数据
  void runfoward(int i);//直走
  void runback(int j);//回头
  void turnL(int m, int n, int h, int k);//左转
  void turnL_s(int m, int n, int h, int k);//原地左转
  void turnR(int m, int n, int h, int k);//右转
  void turnR_s(int m, int n, int h, int k);//原地右转
  void stop();//停
  void followline(int i);//巡线(对i号传感器巡线)
private:
  void motor(char pin,char pwmpin,char state,int val);
  int leftA_PIN;//记录引脚位置
  int leftB_PIN;
  int righA_PIN;
  int righB_PIN;
  int leftA_B_PIN;//记录引脚位置
  int leftB_B_PIN;
  int righA_B_PIN;
  int righB_B_PIN;
  
};

#endif

#include"car.h"
#include<arduino.h>
car::car(int LA, int LB, int RA, int RB,int L1, int L2, int R1, int R2)//一些变量的初始化
{
  f = 0;
  k = 0;
  int leftA_PIN=LA;//记录引脚位置
  int leftB_PIN=LB;
  int righA_PIN=RA;
  int righB_PIN=RB;
  int leftA_B_PIN=L1;
  int leftB_B_PIN=L2;
  int righA_B_PIN=R1;
  int righB_B_PIN=R2;
  pinMode(leftA_PIN, OUTPUT);
  pinMode(leftB_PIN, OUTPUT);
  pinMode(righA_PIN, OUTPUT);
  pinMode(righB_PIN, OUTPUT);
  pinMode(leftA_B_PIN, OUTPUT);
  pinMode(leftB_B_PIN, OUTPUT);
  pinMode(righA_B_PIN, OUTPUT);
  pinMode(righB_B_PIN, OUTPUT);
}
int car::lcd_read()//更新lcd的数值
{
  int sum = 0;
  lcd[0] = analogRead(A0) > 750 ? 1 : 0;
  lcd[1] = analogRead(A1) > 750 ? 1 : 0;
  lcd[2] = analogRead(A2) > 950 ? 1 : 0;
  lcd[3] = analogRead(A3) >= 950 ? 1 : 0;
  lcd[4] = analogRead(A6) > 750 ? 1 : 0;


  lcd_s[0] = analogRead(A0);//>999? 1:0;
  lcd_s[1] = analogRead(A1);//>995? 1:0;
  lcd_s[2] = analogRead(A2);//>997? 1:0;
  lcd_s[3] = analogRead(A3);//>=999? 1:0;
  lcd_s[4] = analogRead(A6);//>997? 1:0;
  for (int i = 0; i < 5; i++) {
    sum += lcd[i];
  }
  return sum;
}
void car::motor(char pin, char pwmpin, char state, int val)
{

  pinMode(pin, OUTPUT);
  if (state == 1)
  {
    analogWrite(pwmpin, val);
    digitalWrite(pin, 1);
  }
  else if (state == 2)
  {
    analogWrite(pwmpin, val);
    digitalWrite(pin, 0);
  }
  else if (state == 0)
  {
    analogWrite(pwmpin, 0);
    digitalWrite(pin, 0);
  }
}
void car::runfoward(int i)   //前进
{
  motor(23, 22, 1, i);
  motor(25, 24, 1, i);
  motor(26, 27, 1, i);
  motor(28, 29, 1, i);
}
void car::runback(int j)    //后退
{
  motor(22, 23, 2, j);
  motor(24, 25, 2, j);
  motor(26, 27, 2, j);
  motor(28, 29, 2, j);
}
void car::turnL_s(int m, int n, int h, int k)     //左转
{
  motor(22, 23, 1, m);
  motor(24, 25, 1, n);
  motor(26, 27, 1, h);
  motor(28, 29, 1, k);
}
void car::turnL(int m, int n, int h, int k)      //原地左转
{
  motor(22, 23, 1, m);
  motor(24, 25, 2, n);
  motor(26, 27, 1, h);
  motor(28, 29, 2, k);
}
void car::turnR_s(int m, int n, int h, int k)      //右转 
{
  motor(22, 23, 1, m);
  motor(24, 25, 1, n);
  motor(26, 27, 1, h);
  motor(28, 29, 1, k);
}
void car::turnR(int m, int n, int h, int k)       //原地右转 
{
  motor(22, 23, 1, m);
  motor(24, 25, 2, n);
  motor(26, 27, 1, h);
  motor(28, 29, 2, k);
}
void car::stop()            //停止
{
  motor(22, 23, 1, 0);
  motor(24, 25, 0, 0);
  motor(26, 27, 1, 0);
  motor(28, 29, 0, k);
}
/*
void car::followline(int i=2)//巡线(在写)
{
  //仅仅完成了i=2的情况（即、沿中间传感器巡线）
  lcd_read();
  if(lcd_read()>3)//如果黑色的部分少于或等于两个、可以认为处在黑线上、而不是路口
  {
    f=0;
  if(lcd[i-2]==0 && lcd[i]==1){//右边检测到黑线、右转
    turnR(100);
    delay(70);
    while(lcd[i+1]!= 0&&lcd[i]!=0){
      delayMicroseconds(2);
      lcd_read();
      }
    turnL(100);//左回转减小误差
    delay(70);
    runfoward(100);
  }
  else  if(lcd[i-1]==0){//右边检测到黑线、右转
    turnR(100);
    while(lcd[i+1]!= 0&&lcd[i]!=0){
      delayMicroseconds(2);
      lcd_read();
      }
    turnL(130);//左回转减小误差
    delay(70);
    runfoward(100);
  }
  else if(lcd[i+2]==0 && lcd[i]==1){//左边检测到黑线、左转
    turnL(100);
    while(lcd[i-1]!= 0&&lcd[i]!=0){
      delayMicroseconds(2);
      lcd_read();
      }
    turnR(100);//右回转减小误差
    delay(70);
    runfoward(100);
  }
  else if(lcd[i+1]==0 ){
    turnL(100);
    while(lcd[i-1]!= 0&&lcd[i]!=0){//左边检测到黑线、左转
      delayMicroseconds(2);
      lcd_read();
      }
    turnR(100);//右回转减小误差
    delay(70);
    runfoward(80);
  }
   else runfoward(100);
    delayMicroseconds(2);
  }
  else {
    
    
    if(f==0)//当从线到路口的时候
    {
      
      f = 1;//标志变量修改
      runfoward(80);
      delay(50);
      /*
      k++;
      if(k>10){
        k=0;
        turnL_s(100);
        delay(4500);
        while(lcd[i+1]!= 1||lcd[i]!=1){
          delayMicroseconds(2);
          lcd_read();
          }
        
        }*/
        /*
      }
     }
 }
 */

    

#include"car.h"
#include<arduino.h>
car::car(int LA,int LB,int RA,int RB)//一些变量的初始化
{
  f=0;
  k=0;
  leftA_PIN=LA;
  leftB_PIN=LB;
  righA_PIN=RA;
  righB_PIN=RB; 
  pinMode(leftA_PIN,OUTPUT);  
  pinMode(leftB_PIN,OUTPUT);
  pinMode(righA_PIN,OUTPUT);
  pinMode(righB_PIN,OUTPUT);
}
int car::lcd_read()//更新lcd的数值
{
  int sum=0;
  lcd[0]= analogRead(A0)>750? 1:0;
  lcd[1]= analogRead(A1)>750? 1:0;
  lcd[2]= analogRead(A2)>950? 1:0;
  lcd[3]= analogRead(A3)>=950? 1:0;
  lcd[4]= analogRead(A6)>750? 1:0;
  lcd_s[0]= analogRead(A0);//>999? 1:0;
  lcd_s[1]= analogRead(A1);//>995? 1:0;
  lcd_s[2]= analogRead(A2);//>997? 1:0;
  lcd_s[3]= analogRead(A3);//>=999? 1:0;
  lcd_s[4]= analogRead(A6);//>997? 1:0;
  for(int i =0;i<5;i++){
    sum+=lcd[i];
  }
  return sum;
}
void car::motor(char pin,char pwmpin,char state,int val)
{

    pinMode(pin, OUTPUT);   
  if(state==1)
  {  
    analogWrite(pwmpin,val);
    digitalWrite(pin,1);
   }
  else if(state==2)
 {  
   analogWrite(pwmpin,val);
   digitalWrite(pin,0);
 }
 else if(state==0)
 {
    analogWrite(pwmpin,0);
    digitalWrite(pin,0);
 }
}
void car::runfoward(int i)   //前进
{
  motor(4,5,1,i);
  motor(7,6,1,i);
}
void car::runback(int j)    //后退
{
   motor(4,5,2,j);
   motor(7,6,2,j); 
}
void car::turnL_s(int m)     //左转
{
  motor(4,5,1,m);
  motor(7,6,0,m);
}
void car::turnL(int m)     //原地左转
{
  motor(4, 5, 1, m);
  motor(7, 6, 2, m);
}
void car::turnR(int n)      //右转 
{
  motor(4, 5, 0, n);
  motor(7, 6, 1, n);
}
void car::turnR_s(int n)      //右转 
{
  motor(4, 5, 2, n);
  motor(7, 6, 1, n);
}
void car::stop()            //停止
{
  motor(4,5,0,0);
  motor(7,6,1,0); 
}
void car::followline(int i=2)//巡线(在写)
{
  //仅仅完成了i=2的情况（即、沿中间传感器巡线）
  lcd_read();
  if(lcd_read()>3)//如果黑色的部分少于或等于两个、可以认为处在黑线上、而不是路口
  {
    f=0;
  if(lcd[i-2]==0 && lcd[i]==1){//右边检测到黑线、右转
    turnR(100);
    delay(70);
    while(lcd[i+1]!= 0&&lcd[i]!=0){
      delayMicroseconds(2);
      lcd_read();
      }
    turnL(100);//左回转减小误差
    delay(70);
    runfoward(100);
  }
  else  if(lcd[i-1]==0){//右边检测到黑线、右转
    turnR(100);
    while(lcd[i+1]!= 0&&lcd[i]!=0){
      delayMicroseconds(2);
      lcd_read();
      }
    turnL(130);//左回转减小误差
    delay(70);
    runfoward(100);
  }
  else if(lcd[i+2]==0 && lcd[i]==1){//左边检测到黑线、左转
    turnL(100);
    while(lcd[i-1]!= 0&&lcd[i]!=0){
      delayMicroseconds(2);
      lcd_read();
      }
    turnR(100);//右回转减小误差
    delay(70);
    runfoward(100);
  }
  else if(lcd[i+1]==0 ){
    turnL(100);
    while(lcd[i-1]!= 0&&lcd[i]!=0){//左边检测到黑线、左转
      delayMicroseconds(2);
      lcd_read();
      }
    turnR(100);//右回转减小误差
    delay(70);
    runfoward(80);
  }
   else runfoward(100);
    delayMicroseconds(2);
  }
  else {
    
    
    if(f==0)//当从线到路口的时候
    {
      
      f = 1;//标志变量修改
      runfoward(80);
      delay(50);
      /*
      k++;
      if(k>10){
        k=0;
        turnL_s(100);
        delay(4500);
        while(lcd[i+1]!= 1||lcd[i]!=1){
          delayMicroseconds(2);
          lcd_read();
          }
        
        }*/
      }
     }
 }

    

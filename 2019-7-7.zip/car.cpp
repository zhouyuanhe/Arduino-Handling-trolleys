#include"car.h"
#include<arduino.h>
int car::measure(int a, int b)
{
  if (a == 1 && b == 2)
    return 1;
  else if (a == 0 && b == 2)
    return 2;
  else if (a == 4 && b == 2)
    return 3;
  else if (a == 5 && b == 2)
    return 4;
  else return -1;
}
void car::fix(int cwbsecond)
{
  PRECWB=cwbsecond;
}

car::car(int LA, int LB, int RA, int RB, int L1, int L2, int R1, int R2)//一些变量的初始化
{
  f = 0;
  k = 0;
  int leftA_PIN = LA;//记录引脚位置
  int leftB_PIN = LB;
  int righA_PIN = RA;
  int righB_PIN = RB;
  int leftA_B_PIN = L1;
  int leftB_B_PIN = L2;
  int righA_B_PIN = R1;
  int righB_B_PIN = R2;
  pinMode(leftA_PIN, OUTPUT);
  pinMode(leftB_PIN, OUTPUT);
  pinMode(righA_PIN, OUTPUT);
  pinMode(righB_PIN, OUTPUT);
  pinMode(leftA_B_PIN, OUTPUT);
  pinMode(leftB_B_PIN, OUTPUT);
  pinMode(righA_B_PIN, OUTPUT);
  pinMode(righB_B_PIN, OUTPUT);
}
void car::lcd_read()//更新lcd的数值
{
  for (int i = 0; i < 5; i++) {
    lcd[0] += analogRead(A4) > 750 ? 1 : 0;
    lcd[1] += analogRead(A0) > 750 ? 1 : 0;
    lcd[2] += analogRead(A2) > 750 ? 1 : 0;
    lcd[3] += analogRead(A1) > 750 ? 1 : 0;
    lcd[4] += analogRead(A3) > 750 ? 1 : 0;
    lcd[5] += analogRead(A5) > 750 ? 1 : 0;
    
  }
  
    lcd_s[0] = analogRead(A4) ;
    lcd_s[1] = analogRead(A0) ;
    lcd_s[2] = analogRead(A2) ;
    lcd_s[3] = analogRead(A1) ;
    lcd_s[4] = analogRead(A3) ;
    lcd_s[5] = analogRead(A5) ;
  lcd[0] = lcd[0] > 2 ? 1 : 0;
  lcd[1] = lcd[1] > 2 ? 1 : 0;
  lcd[2] = lcd[2] > 2 ? 1 : 0;
  lcd[3] = lcd[3] > 2 ? 1 : 0;
  lcd[4] = lcd[4] > 2 ? 1 : 0;
  lcd[5] = lcd[5] > 2 ? 1 : 0;
  //if(lcd[2]==0&&lcd[5]==0){}//中间
  if(lcd[2]==0&&lcd[3]==1){fix(NOWCWB);NOWCWB=0;}//偏左
  else if(lcd[1]==1&&lcd[2]==0){fix(NOWCWB);NOWCWB=1;}//偏右
  else if(lcd[0]==0&&lcd[2]==1){fix(NOWCWB);NOWCWB=4;}//极偏左
  else if(lcd[4]==0&&lcd[2]==1){fix(NOWCWB);NOWCWB=5;}//极偏右
  else if(lcd[0]==1&&lcd[1]==1&&lcd[2]==1&&lcd[3]==1&&lcd[4]==1&&lcd[5]==1){NOWCWB=-1;fix(NOWCWB);}//原地左转
  else{fix(NOWCWB);NOWCWB=2;}
//  Serial.print(lcd[0]);
//  Serial.print(lcd[1]);
//  Serial.print(lcd[2]);
//  Serial.print(lcd[3]);
//  Serial.print(lcd[4]);
//  Serial.println(lcd[5]);
//  Serial.println(lcd_s[0]);
//  Serial.println(lcd_s[1]);
//  Serial.println(lcd_s[2]);
//  Serial.println(lcd_s[3]);
//  Serial.println(lcd_s[4]);
//  Serial.println(lcd_s[5]);
//  Serial.println(NOWCWB);
//  Serial.println(NOWCWB);
//  delay(5000);
}
void car::motor(char pin, char pwmpin, char state, int val)
{

  pinMode(pin, OUTPUT);
  if (state == 1)
  {
    analogWrite(pwmpin, val);
    digitalWrite(pin, 1);
  }
  else if (state == 2)
  {
    analogWrite(pin, val);
    digitalWrite(pwmpin, 1);
  }
  else if (state == 0)
  {
    analogWrite(pwmpin, 0);
    digitalWrite(pin, 0);
  }
}
void car::runfoward(int i)   //前进
{
  motor(2, 3, 1, 255-i);
  motor(4, 5, 1, 255-i);
  motor(6, 7, 1, 255-i);
  motor(8, 9, 1, 255-i);
}
void car::runback(int j)    //后退
{
  motor(2, 3, 2, 255-j);
  motor(4, 5, 2, 255-j);
  motor(6, 7, 2, 255-j);
  motor(8, 9, 2, 255-j);
}
void car::turnL_s(int m)     //左转
{
  motor(2, 3, 1, 255);
  motor(4, 5, 1, 255);
  motor(6, 7, 1, 255-m);
  motor(8, 9, 1, 255-m);
}
void car::turnL()      //原地左转
{
  motor(2, 3, 2, 125);
  motor(4, 5, 2, 255);
  motor(6, 7, 1, 125);
  motor(8, 9, 1, 255);
}
void car::turnR_s(int m)      //右转 
{
  motor(2, 3, 1, 255-m);
  motor(4, 5, 1, 255-m);
  motor(6, 7, 1, 255);
  motor(8, 9, 1, 255);
}
void car::turnR()       //原地右转 
{
  motor(2, 3, 1, 255);
  motor(4, 5, 1, 125);
  motor(6, 7, 2, 255);
  motor(8, 9, 2, 125);
}
void car::stop()            //停止
{
  motor(2, 3, 1, 255);
  motor(4, 5, 0, 255);
  motor(6, 7, 1, 255);
  motor(8, 9, 0, 255);
}
void car::followline() {
  lcd_read();
  for(int i=1;i<=6;i++){
//      Serial.println(i);
//      Serial.println(PRECWB);
//      Serial.println(NOWCWB);
//      delay(5000);
    switch (i){
      case 1:{
        if(NOWCWB==0){
          turnL_s(140);
          delay(30);
          runmethod=0;
          lcd_read();
          break;}
        }
      case 2:{
         if(NOWCWB==1){
          turnR_s(140);
          delay(30);
          runmethod=1;
          lcd_read();
          break;}
        }
      case 3:{
         if(NOWCWB==2){
          runfoward(170);
          delay(30);
          runmethod=2;
          lcd_read();
          break;}
        }
      case 4:{
         if(NOWCWB==4){
          turnL();
          delay(30);
          runmethod=4;
          lcd_read();
          break;}
        }
      case 5:{
         if(NOWCWB==5){
          turnR();
          delay(30);
          runmethod=5;
          lcd_read();
          break;}
        }
       default:{
        if(NOWCWB==-1){
          turnL_s(140);
          delay(50);
          runmethod=0;
          lcd_read();
          break;}
      }
    }
  }
  int time=30;
  while(NOWCWB==PRECWB&&NOWCWB!=2){
      time=time/2;
//      Serial.println(PRECWB);
//      Serial.println(NOWCWB);
//      Serial.print("方式");
//      Serial.println(runmethod);
//      delay(5000);
      switch (runmethod){
        case 0:{
            turnL_s(140);
            delay(time);
            lcd_read();
            break;
          }
        case 1:{
            turnR_s(140);
            delay(time);
            lcd_read();
            break;
        }
        case 2:{
            runfoward(170);
            delay(time);
            lcd_read();
            break;
          }
        case 4:{
            turnL();
            delay(time);
            lcd_read();
            break;
          }
        case 5:{
            turnR();
            delay(time);
            lcd_read();
            break;
          }
      }
  }
  if(measure(PRECWB,NOWCWB)==1){
      turnL();
      delay(1);
    }
  else if(measure(PRECWB,NOWCWB)==2){
      turnR();
      delay(1);
    }
  else if(measure(PRECWB,NOWCWB)==3){
      turnR();
      delay(2);
    }
  else if(measure(PRECWB,NOWCWB)==4){
      turnL();
      delay(2);
    }
  else return;
//  delay(10000);
  }
//  if (flag < 5) {
//    if (lcd[i - 2] == 1 && lcd[i - 1] == 0 && lcd[i] == 0 && lcd[i + 1] == 1 && lcd[i + 2] == 1)
//    {
//      turnL_s(170);
//      delay(100);
//      while (lcd[i-1] == 0) {
//        delayMicroseconds(2);
//        lcd_read();
//      }
//      //turnR(150);//反向转，抵消惯性力，
//      //delay(10);
//    }
//    else if (lcd[i - 2] == 1 && lcd[i - 1] == 1 && lcd[i] == 0 && lcd[i + 1] == 0 && lcd[i + 2] == 1)
//    {
////      runback(200);//回转,抵消向前惯性
////      delay(20);
//      turnR_s(170);
//      delay(100);
//      while (lcd[i+1] == 0) {
//        delayMicroseconds(2);
//        lcd_read();
//      }
//      //turnL(150);//反向转，抵消惯性力，
//      //delay(10);
//    }
//    else if (lcd[i - 2] == 1 && lcd[i - 1] == 0 && lcd[i] == 1 && lcd[i + 1] == 1 && lcd[i + 2] == 1)
//    {
////      runback(200);//回转,抵消向前惯性
////      delay(20);
//      turnL(170);
//      delay(100);
//      while (lcd[i] != 0) {
//        delayMicroseconds(2);
//        lcd_read();
//      }
//      //turnR(150);//反向转，抵消惯性力，
//      //delay(1);
//    }
//    else if (lcd[i - 2] == 1 && lcd[i - 1] == 1 && lcd[i] == 1 && lcd[i + 1] == 0 && lcd[i + 2] == 1)
//    {
////      runback(200);//回转,抵消向前惯性
////      delay(20);
//      turnR(170);
//      delay(100);
//      while (lcd[i] != 0) {
//        delayMicroseconds(2);
//        lcd_read();
//      }
//      //turnL(150);//反向转，抵消惯性力，
//      //delay(10);
//    }
//    else if (lcd[i - 2] == 0 && lcd[i - 1] == 0 && lcd[i] == 1 && lcd[i + 1] == 1 && lcd[i + 2] == 1)
//    {
////      runback(200);//回转,抵消向前惯性
////      delay(20);
//      turnL_s(170);
//      delay(100);
//      while (lcd[i] != 0) {
//        delayMicroseconds(2);
//        lcd_read();
//      }
//      //turnR(150);//反向转，抵消惯性力，
//      //delay(10);
//    }
//    else if (lcd[i - 2] == 1 && lcd[i - 1] == 1 && lcd[i] == 1 && lcd[i + 1] == 0 && lcd[i + 2] == 0)
//    {
////      runback(200);//回转,抵消向前惯性
////      delay(20);
//      turnR(170);
//      delay(100);
//      while (lcd[i] != 0) {
//        delayMicroseconds(2);
//        lcd_read();
//      }
//      //turnL(150);//反向转，抵消惯性力，
//      //delay(10);
//    }
//    else if (lcd[i - 2] == 0 && lcd[i - 1] == 1 && lcd[i] == 1 && lcd[i + 1] == 1 && lcd[i + 2] == 1)
//    {
////      runback(200);//回转,抵消向前惯性
////      delay(20);
//      turnL(170);
//      delay(100);
//      while (lcd[i] != 0) {
//        delayMicroseconds(2);
//        lcd_read();
//      }
//      //runfoward(200);//反向转，抵消惯性力，
//      //delay(10);
//    }
//    else if (lcd[i - 2] == 1 && lcd[i - 1] == 1 && lcd[i] == 1 && lcd[i + 1] == 1 && lcd[i + 2] == 0)
//    {
////      runback(200);//回转,抵消向前惯性
////      delay(20);
//      turnR(170);
//      delay(100);
//      while (lcd[i] != 0) {
//        delayMicroseconds(2);
//        lcd_read();
//      }
////      runfoward(200);//反向转，抵消惯性力，
////      delay(1);
//    }
//    else {
//      runfoward(225);
//      delay(80);
//    }
//  }
//  else {
//    turnL(180);
//    delay(50);
//  }
/*
void car::followline(int i=2)//巡线(在写)
{
  //仅仅完成了i=2的情况（即、沿中间传感器巡线）
  lcd_read();
  if(lcd_read()>3)//如果黑色的部分少于或等于两个、可以认为处在黑线上、而不是路口
  {
  f=0;
  if(lcd[i-2]==0 && lcd[i]==1){//右边检测到黑线、右转
  turnR(100);
  delay(70);
  while(lcd[i+1]!= 0&&lcd[i]!=0){
    delayMicroseconds(2);
    lcd_read();
    }
  turnL(100);//左回转减小误差
  delay(70);
  runfoward(100);
  }
  else  if(lcd[i-1]==0){//右边检测到黑线、右转
  turnR(100);
  while(lcd[i+1]!= 0&&lcd[i]!=0){
    delayMicroseconds(2);
    lcd_read();
    }
  turnL(130);//左回转减小误差
  delay(70);
  runfoward(100);
  }
  else if(lcd[i+2]==0 && lcd[i]==1){//左边检测到黑线、左转
  turnL(100);
  while(lcd[i-1]!= 0&&lcd[i]!=0){
    delayMicroseconds(2);
    lcd_read();
    }
  turnR(100);//右回转减小误差
  delay(70);
  runfoward(100);
  }
  else if(lcd[i+1]==0 ){
  turnL(100);
  while(lcd[i-1]!= 0&&lcd[i]!=0){//左边检测到黑线、左转
    delayMicroseconds(2);
    lcd_read();
    }
  turnR(100);//右回转减小误差
  delay(70);
  runfoward(80);
  }
   else runfoward(100);
  delayMicroseconds(2);
  }
  else {


  if(f==0)//当从线到路口的时候
  {

    f = 1;//标志变量修改
    runfoward(80);
    delay(50);
    /*
    k++;
    if(k>10){
    k=0;
    turnL_s(100);
    delay(4500);
    while(lcd[i+1]!= 1||lcd[i]!=1){
      delayMicroseconds(2);
      lcd_read();
      }

    }*/
    /*
    }
   }
 }
 */
